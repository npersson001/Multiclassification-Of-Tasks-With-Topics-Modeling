package edu.unc.cs.projectTracer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import edu.unc.cs.projectTracer.schema.CommandType;
import edu.unc.cs.projectTracer.schema.DocumentChangeType;
import edu.unc.cs.projectTracer.schema.Events;

public class ProjectTracer {

	// 16, ?
	// 17, rename
	// 18, rename
	// 19, OK (2 classes in 1 file?)
	// 20, rename
	// 21, OK
	// 22, rename, fixed by ignoring case
	// 23.1, OK
	// 23.2, OK
	// 24.1, OK (spacing at end of car.java)
	// 24.2, ?
	// 26.1, odd
	// 26.2, odd
	// 27, ?
	// 28, rename
	// 29, odd (body.java)
	// 30, rename
	// 31, ?
	// 32, OK
	// 33, rename
	
	// good: 19, 21, 22, 28, 32 (useless), 30
	// acceptable: 20
	// bad: 33, 29
	
	
	private static final String TEST_FILE_PATH = "hermes-test-31.xml";
//	private static final String[] TEST_FILE_PATHS = {"hermes-test-19.xml", "hermes-test-21.xml", "hermes-test-22.xml",
//			"hermes-test-32.xml"};

	private static final Map<String, Document> fileMap;
	private static String currentFile;
	private static String copyBuffer;

	private static boolean selected;
	private static boolean wasSelect;
	private static boolean selectLeft;
	
	private static Serializable previous;
	private static boolean wasInsert;
	private static String inserted;

	static {
		fileMap = new HashMap<>();
		currentFile = null;
		copyBuffer = "";
		selected = false;
		wasSelect = false;
		selectLeft = false;
	}

	public static void main(String[] args) {
//		test();
//		DifficultyPredictionSettings.setReplayMode(true);
//		//
//		Analyzer analyzer = new AnAnalyzer();
//		AnalyzerListener analyzerListener = new ProjectTracer();
//		analyzer.loadDirectory();
//		analyzer.getAnalyzerParameters().getParticipants().setValue("16");
//		analyzer.addAnalyzerListener(analyzerListener);
//		analyzer.getAnalyzerParameters().replayLogs();
		Events events;
		try {
			events = getEvents(TEST_FILE_PATH);
			processEvents(events);
			printFiles();
		} catch (JAXBException e) {
			e.printStackTrace();
		} catch (Exception e) {
			printFiles();
			System.out.flush();
			System.out.println("");
			System.err.println("Current file: " + getCurrentFileName());
			e.printStackTrace();
		}
	}
	
	private static void printFiles() {
		fileMap.forEach((key, value) -> {
			System.out.println("*** " + key + " ***");
			System.out.println("=== cursor: " + value.getCursor());
			System.out.println("=== selection: " + value.getSelectStart() + " to " + value.getSelectEnd());
			System.out.println("=== content");
			System.out.println(value.getContents());
		});
	}

	private static void test() {
		Document doc = new EclipseDocument();
		doc.insert("Hello world\r\ntext\r\nthis is a long line");
		printDocState(doc);
		System.out.println(doc.getContents());
		System.out.println("*** set cursor 6");
		doc.setCursor(6);
		printDocState(doc);
		System.out.println("*** set cursor start");
		doc.cursorStart();
		printDocState(doc);
		System.out.println("*** set cursor 6");
		doc.setCursor(6);
		printDocState(doc);
		System.out.println("*** set cursor end");
		doc.cursorEnd();
		printDocState(doc);
		System.out.println("*** set cursor 32");
		doc.setCursor(32);
		printDocState(doc);
		System.out.println("*** up 1");
		doc.cursorUp(1);
		printDocState(doc);
		System.out.println("*** set cursor 32");
		doc.setCursor(32);
		printDocState(doc);
		System.out.println("*** up 2");
		doc.cursorUp(2);
		printDocState(doc);
		System.out.println("*** set cursor 32");
		doc.setCursor(32);
		printDocState(doc);
		System.out.println("*** up 3");
		doc.cursorUp(3);
		printDocState(doc);
		System.out.println("*** set cursor 23");
		doc.setCursor(23);
		printDocState(doc);
		System.out.println("*** set cursor start");
		doc.cursorStart();
		printDocState(doc);
		System.out.println("*** set cursor 23");
		doc.setCursor(23);
		printDocState(doc);
		System.out.println("*** set cursor end");
		doc.cursorEnd();
		printDocState(doc);
	}

	private static void printDocState(Document doc) {
		System.out.println(doc.getCursor() + " - " + doc.copySelection());
	}

	private static Events getEvents(String fname) throws JAXBException {
		File file = Paths.get(fname).toFile();
		JAXBContext jaxbContext = JAXBContext.newInstance(Events.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		Events events = (Events) jaxbUnmarshaller.unmarshal(file);
		return events;
	}
	
	private static List<Serializable> reorderEvents(Events events) {
		List<Serializable> list = events.getCommandsAndDocumentChanges();
		list.sort(Comparator.comparing(event -> {
			if (event instanceof CommandType) {
				CommandType command = (CommandType)event;
				if (command.getTimestamp2() == null) {
					return command.getTimestamp();
				} else {
					return command.getTimestamp2();
				}
			} else if (event instanceof DocumentChangeType) {
				DocumentChangeType change = (DocumentChangeType)event;
				if (change.getTimestamp2() == null) {
					return change.getTimestamp();
				} else {
					return change.getTimestamp2();
				}
			} else {
				return 0;
			}
		}));
		return list;
	}

	private static void processEvents(Events events) {
		List<Serializable> list = reorderEvents(events);
		int i = 0;
		int timestamp = 0;
		previous = null;
		setInsert(false);
		try {
			for (Serializable element : list) {
				if (selected == false) {
					wasSelect = false;
				} else {
					selected = false;
				}
				if (element instanceof CommandType) {
					CommandType command = (CommandType) element;
					if (timestamp != command.getTimestamp()) {
						timestamp = command.getTimestamp();
						System.out.println("CURRENT TIME: " + formatTimestamp(timestamp));
					}
					System.out.println("Processing command: " + command.get_Type());
					System.out.println("ID: " + command.get__Id());
					CommandProcessor.processCommand(command);
				} else if (element instanceof DocumentChangeType) {
					DocumentChangeType change = (DocumentChangeType) element;
					if (timestamp != change.getTimestamp()) {
						timestamp = change.getTimestamp();
						System.out.println("CURRENT TIME: " + formatTimestamp(timestamp));
					}
					System.out.println("Processing change: " + change.get_Type());
					System.out.println("ID: " + change.get__Id());
					DocumentChangeProcessor.processDocumentChange(change);
				}
				
				try {
					File root = new File("output_docs");
					root.mkdir(); //this makes sure the folder exists
					File file = new File(root, TEST_FILE_PATH.split("\\.")[0] + ".txt");
					PrintStream writeToOutputFile = new PrintStream(new FileOutputStream(file, true));
					for(Entry<String, Document> e : fileMap.entrySet()){
						writeToOutputFile.append(e.getValue().getContents());
						writeToOutputFile.append("\n%%%%%%%%%%%%%%%%%%%%\n");
					}
					writeToOutputFile.append("\n$$$$$$$$$$$$$$$$$$$$\n");
					writeToOutputFile.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} 
				
				i++;
				previous = element;
			}
		} finally {
			System.out.flush();
			System.out.println("Processed " + i + "/" + list.size() + " elements");
		}
	}

	public static boolean hasFile(String name) {
		return fileMap.containsKey(name);
	}

	public static Document getFile(String name) {
		return fileMap.get(name);
	}

	public static Document getCurrentFile() {
		return getFile(currentFile);
	}

	public static String getCurrentFileName() {
		return currentFile;
	}

	public static void setCurrentFileName(String name) {
		currentFile = name;
	}

	public static void addFile(String name, Document file) {
		fileMap.put(name, file);
	}

	public static int getCaretPos() {
		return getCurrentFile().getCursor();
//		return caretPos;
	}

	public static void setCaretPos(int pos) {
		getCurrentFile().setCursor(pos);
//		caretPos = pos;
	}

	public static void setCopied(String str) {
		copyBuffer = str;
	}

	public static String getCopied() {
		return copyBuffer;
	}

	public static Serializable getPrevious() {
		return previous;
	}

	public static void setInsert(boolean newVal) {
		wasInsert = newVal;;
	}

	public static boolean wasInsert() {
		return wasInsert;
	}

	public static String getInserted() {
		return inserted;
	}

	public static void setInserted(String inserted) {
		ProjectTracer.inserted = inserted;
	}

	public static boolean wasSelecting() {
		return wasSelect;
	}

	public static boolean wasSelectingRight() {
		return !selectLeft;
	}

	public static boolean wasSelectingLeft() {
		return selectLeft;
	}

	public static void markSelectingRight() {
		selectLeft = false;
	}

	public static void markSelectingLeft() {
		selectLeft = true;
	}

	public static void markSelected() {
		selected = true;
	}
	
	private static String formatTimestamp(int time) {
		int ms = time % 1000;
		time /= 1000;
		int sec = time % 60;
		time /= 60;
		int min = time % 60;
		time /= 60;
		int hour = time;
		
		return String.format("%d:%02d:%02d.%04d", hour, min, sec, ms);
	}

//	public Serializable mapCommand(EHICommand ehi) {
//		Serializable ret;
//		if ("Command".equals(ehi.getCommandTag())) {
//			CommandType cmd = new CommandType();
//			cmd.setEndLine((byte)ehi.getBottomLineNumber());
//			cmd.setStartLine((byte)ehi.getBottomLineNumber());
//			cmd.set_Type(ehi.getCommandType());
//			
//		}
//	}
}
