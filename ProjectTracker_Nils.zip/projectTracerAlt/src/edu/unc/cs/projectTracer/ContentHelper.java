package edu.unc.cs.projectTracer;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBElement;

public class ContentHelper {
	private Map<String, String> mapping;
	
	private ContentHelper(List<Serializable> contents) {
		mapping = new HashMap<>();
		for(Serializable content : contents) {
			if (content instanceof JAXBElement) {
				JAXBElement<?> element = (JAXBElement<?>)content;
//				System.out.println(element + " - " + element.getName() + " - " + element.getValue() + " - " + element.getValue().getClass());
				mapping.put(element.getName().getLocalPart(), (String)element.getValue());
			}
		}
	}
	public static ContentHelper mapContents(List<Serializable> contents) {
		return new ContentHelper(contents);
	}
	
	public Optional<String> get(String key) {
		if (mapping.containsKey(key)) {
			return Optional.of(mapping.get(key));
		} else {
			return Optional.empty();
		}
	}
}
