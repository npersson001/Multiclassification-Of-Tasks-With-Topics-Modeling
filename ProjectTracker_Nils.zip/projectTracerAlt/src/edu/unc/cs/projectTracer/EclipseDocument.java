package edu.unc.cs.projectTracer;

public class EclipseDocument implements Document {
	private StringBuilder contents;
	
	private int cursor;
	private int selectStart;
	private int selectEnd;
	
	public EclipseDocument() {
		this("");
	}
	

	public EclipseDocument(String contents) {
		this.contents = new StringBuilder(contents);
		cursor = 0;
		selectStart = 0;
		selectEnd = 0;
	}
	
	@Override
	public int addText(int loc, String text) {
		contents.insert(loc, text);
		return text.length();
	}

	@Override
	public int removeText(int loc, int len) {
		len = Math.min(len, contents.length() - loc);
		String after = contents.substring(loc+len);
		contents.setLength(loc);
		contents.append(after);
		return len;
	}

	@Override
	public String getContents() {
		return contents.toString();
	}


	@Override
	public String getText(int start, int length) {
		return contents.substring(start, start+length);
	}


	@Override
	public void setCursor(int pos) {
		cursor = pos;
	}


	@Override
	public int getCursor() {
		return cursor;
	}


	@Override
	public void cursorUp(int dist) {
		setCursor(peekCursorUp(dist));
	}


	@Override
	public void cursorDown(int dist) {
		setCursor(peekCursorDown(dist));
	}


	@Override
	public void cursorLeft(int dist) {
		setCursor(peekCursorLeft(dist));
	}


	@Override
	public void cursorRight(int dist) {
		setCursor(peekCursorRight(dist));
	}


	@Override
	public void cursorStart() {
		setCursor(peekCursorStart());
	}


	@Override
	public void cursorEnd() {
		setCursor(peekCursorEnd());
	}


	@Override
	public int peekCursorUp(int dist) {
		int offset = cursor - contents.lastIndexOf("\n", cursor);
		if (offset > cursor) {
			return 0;
		}

		offset --;
		
		int start = cursor - offset;
		for (int i = 0; i < dist; i ++) {
			if (start == 0) {
				return contents.length();
			}
			start = Math.max(0, contents.lastIndexOf("\n", start - 2)+1);
		}

		offset = Math.min(offset, Math.min(contents.indexOf("\r", start+1), contents.indexOf("\n", start+1)) - start);
		
		return start + offset;
	}


	@Override
	public int peekCursorDown(int dist) {
		int offset = Math.min(cursor, cursor - contents.lastIndexOf("\n", cursor) - 1);
		
		int start = cursor;
		for (int i = 0; i < dist; i ++) {
			if (start == contents.length()) {
				return contents.length();
			}
			start = contents.indexOf("\n", start)+1;
			if (start == 0) {
				start = contents.length();
			}
		}
		if (start == contents.length()) {
			return contents.length();
		}

		int distToEnd = Math.min(contents.indexOf("\r", start+1), contents.indexOf("\n", start+1)) - start;
		offset = Math.min(offset, contents.length() - start);
		if (distToEnd >= 0) {
			offset = Math.min(offset, distToEnd);
		}
		
		return start + offset;
	}


	@Override
	public int peekCursorLeft(int dist) {
		return Math.max(0, cursor - dist);
	}


	@Override
	public int peekCursorRight(int dist) {
		return Math.min(contents.length(), cursor + dist);
	}


	@Override
	public int peekCursorStart() {
		int newLinePos = contents.lastIndexOf("\n", cursor);
//		if (newLinePos == cursor) {
//			return newLinePos;
//		} else {
			return Math.max(0, newLinePos+1);
//		}
	}


	@Override
	public int peekCursorEnd() {
		int end = Math.min(contents.indexOf("\r", cursor),contents.indexOf("\n", cursor));
		if (end < 0) {
			return contents.length();
		} else {
			return end;
		}
	}


	@Override
	public String copySelection() {
		return contents.substring(selectStart, selectEnd);
	}


	@Override
	public String cutSelection() {
		String selection = copySelection();
		deleteSelection();
		return selection;
	}


	@Override
	public void deleteSelection() {
		removeText(selectStart, selectEnd-selectStart);
	}


	@Override
	public void insert(String text) {
		addText(cursor, text);
		cursorRight(text.length());
	}


	@Override
	public void removeBefore(int len) {
		if (cursor > 0) {
			for(int i = 0; i < len ; i ++) {
				if (cursor-i > 0 && contents.charAt(cursor-i) == '\n') {
					if (contents.charAt(cursor-i-1) == '\r') {
						len ++;
					}
				}
			}
			len = removeText(cursor-len, len);
			cursorLeft(len);
		}
	}


	@Override
	public void removeAfter(int len) {
		for(int i = 0; i < len ; i ++) {
			if (contents.charAt(cursor+i) == '\r') {
				len ++;
			}
		}
		removeText(cursor, len);
	}


	@Override
	public void setSelect(int start, int end) {
		selectStart = start;
		selectEnd = end;
	}


	@Override
	public int getSelectStart() {
		return selectStart;
	}

	@Override
	public int getSelectEnd() {
		return selectEnd;
	}


	@Override
	public void setContents(String newContent) {
		this.contents = new StringBuilder(newContent);
		if (selectEnd > contents.length()) {
			selectEnd = contents.length();
		}
		if (cursor > contents.length()) {
			cursor = contents.length();
		}
	}

	@Override
	public int getLength() {
		return contents.length();
	}
}
