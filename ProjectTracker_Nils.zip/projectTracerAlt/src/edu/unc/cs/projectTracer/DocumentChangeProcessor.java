package edu.unc.cs.projectTracer;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBElement;

import edu.unc.cs.projectTracer.schema.DocumentChangeType;

public class DocumentChangeProcessor {

	private static final String INSERT_CHANGE = "Insert";
	private static final String DELETE_CHANGE = "Delete";
	private static final String REPLACE_CHANGE = "Replace";

	private static final String TEXT_ELEMENT = "text";
	private static final String INSERTED_TEXT_ELEMENT = "insertedText";
	private static final String DELETED_TEXT_ELEMENT = "deletedText";
	
	public static void processDocumentChange(DocumentChangeType change) {
		Byte repeat = change.getRepeat();
		if (repeat == null) {
			repeat = 1;
		}
		repeat = 1;
		for(int i = 0; i < repeat; i ++) {
			if (INSERT_CHANGE.equals(change.get_Type())) {
				processInsertChange(change);
			} else if (DELETE_CHANGE.equals(change.get_Type())) {
				processDeleteChange(change);
			} else if (REPLACE_CHANGE.equals(change.get_Type())) {
				processReplaceChange(change);
			} else {
				System.out.println("Unprocessed change type: " + change.get_Type());
			}
		}
	}
	
	public static void reprocessInsert(DocumentChangeType change) {
		processInsertChange(change);
	}
	
	private static void processInsertChange(DocumentChangeType change) {
		ProjectTracer.setInsert(true);
		System.out.println("\tInsert of length " + change.getLength() + " at " + ProjectTracer.getCurrentFile().getCursor());
		
		ContentHelper contents = ContentHelper.mapContents(change.getContent());
		Optional<String> addedText = contents.get(TEXT_ELEMENT);
		
		if (addedText.isPresent()) {
			String added = addedText.get();
			if (change.getLength() > added.length()) {
				added = added.replaceAll("\r?\n", "\r\n");
			}
			if (ProjectTracer.getPrevious() instanceof DocumentChangeType) {
				if (REPLACE_CHANGE.equals(((DocumentChangeType)ProjectTracer.getPrevious()).get_Type())) {
					ProjectTracer.setInserted(ProjectTracer.getInserted() + added);
				} else {
					ProjectTracer.setInserted(added);
				}
			} else {
				ProjectTracer.setInserted(added);
			}
			System.out.println("\t\tInserting: " + added);
			int start = change.getOffset();
			int cursor = ProjectTracer.getCurrentFile().getCursor();
			ProjectTracer.getCurrentFile().addText(start, added);
			
			ProjectTracer.getCurrentFile().setCursor(start + change.getLength());
			
//			if (cursor > start) {
//				ProjectTracer.getCurrentFile().cursorRight(added.length());
//			}
			
			System.out.println("*** begin new file ***");
			System.out.println(ProjectTracer.getCurrentFile().getContents());
			System.out.println("*** end new file ***");
		} else {
			System.out.println("\t\tNo inserted text given");
		}
	}
	
	private static void processDeleteChange(DocumentChangeType change) {
//		ProjectTracer.setInsert(false);
		ContentHelper contents = ContentHelper.mapContents(change.getContent());
		Optional<String> deletedText = contents.get(TEXT_ELEMENT);
		int length = change.getLength();
		System.out.println("\tDeletion of length " + length + " at " + change.getOffset());
		if (deletedText.isPresent()) {
			System.out.println("\t\tNo deleted text given");
		}
		int start = change.getOffset();
		int end = start + length;
		int cursor = ProjectTracer.getCurrentFile().getCursor();
		if (cursor > start && cursor <= end) {
			ProjectTracer.getCurrentFile().setCursor(start);
		} else if (cursor > end) {
			ProjectTracer.getCurrentFile().cursorLeft(length);
		}
		System.out.println("\t\tDelete " + start + " to " + end);
		String removing = ProjectTracer.getCurrentFile().getContents().substring(start, end);
		System.out.println("\t\tRemoving: " + removing);
		System.out.println("\t\tBytes: " + Arrays.toString(removing.getBytes()));
		ProjectTracer.getCurrentFile().removeText(start, change.getLength());
		System.out.println("*** begin new file ***");
		System.out.println(ProjectTracer.getCurrentFile().getContents());
		System.out.println("*** end new file ***");
	}

	private static void processReplaceChange(DocumentChangeType change) {
//		ProjectTracer.setInsert(false);
		ContentHelper contents = ContentHelper.mapContents(change.getContent());
		Optional<String> insertedText = contents.get(INSERTED_TEXT_ELEMENT);
		Optional<String> removedText = contents.get(DELETED_TEXT_ELEMENT);
		if (insertedText.isPresent()) {
			ProjectTracer.setInsert(true);
			int start = change.getOffset();
			int end = start + change.getLength();
			int length = change.getLength();
			int cursor = ProjectTracer.getCurrentFile().getCursor();
			
			System.out.println("\tDeletion of length " + change.getLength() + " at " + change.getOffset());
			System.out.println("\t\tDeleting: " + removedText.get());
			ProjectTracer.getCurrentFile().removeText(start, length);
			if (cursor > start && cursor <= end) {
				ProjectTracer.getCurrentFile().setCursor(start);
			} else if (cursor > end) {
				ProjectTracer.getCurrentFile().cursorLeft(length);
			}
			
			System.out.println("\tInsert of length " + change.getInsertionLength() + " at " + change.getOffset());

			String added = insertedText.get();
			ProjectTracer.setInserted(added);
			System.out.println("\t\tInserting: " + added);
			if (change.getInsertionLength() > added.length()) {
				added = added.replaceAll("\r?\n", "\r\n");
			}
			ProjectTracer.getCurrentFile().addText(start, added);
			if (cursor > start) {
				ProjectTracer.getCurrentFile().cursorRight(change.getInsertionLength());
			}
			
			System.out.println("*** begin new file ***");
			System.out.println(ProjectTracer.getCurrentFile().getContents());
			System.out.println("*** end new file ***");
		} else {
			System.out.println("\t\tNo inserted text given");
		}
	}
}
