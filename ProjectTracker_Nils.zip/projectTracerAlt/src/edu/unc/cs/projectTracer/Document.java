package edu.unc.cs.projectTracer;

public interface Document {
	public void setCursor(int pos);
	public int getCursor();
	
	public void cursorUp(int dist);
	public void cursorDown(int dist);
	public void cursorLeft(int dist);
	public void cursorRight(int dist);
	public void cursorStart();
	public void cursorEnd();
	
	public int peekCursorUp(int dist);
	public int peekCursorDown(int dist);
	public int peekCursorLeft(int dist);
	public int peekCursorRight(int dist);
	public int peekCursorStart();
	public int peekCursorEnd();
	
	public String copySelection();
	public String cutSelection();
	public void deleteSelection();
	public void setSelect(int start, int end);
	public int getSelectStart();
	public int getSelectEnd();
	
	public void insert(String text);
	public void removeBefore(int len);
	public void removeAfter(int len);
	
	public int addText(int loc, String text);
	public int removeText(int loc, int len);
	public String getText(int start, int length);
	public String getContents();
	public void setContents(String newContent);
	
	public int getLength();
}
