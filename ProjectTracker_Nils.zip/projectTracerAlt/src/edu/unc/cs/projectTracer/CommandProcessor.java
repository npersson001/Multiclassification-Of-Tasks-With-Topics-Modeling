package edu.unc.cs.projectTracer;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;

import javax.xml.bind.JAXBElement;

import edu.unc.cs.projectTracer.schema.CommandType;
import edu.unc.cs.projectTracer.schema.DocumentChangeType;

public class CommandProcessor {
	private static final String MOVE_CARET_COMMAND = "MoveCaretCommand";
	private static final String FILE_OPEN_COMMAND = "FileOpenCommand";
	private static final String ECLISPE_COMMAND = "EclipseCommand";
	private static final String INSERT_STRING_COMMAND = "InsertStringCommand";
	private static final String SELECT_TEXT_COMMAND = "SelectTextCommand";
	private static final String COPY_COMMAND = "CopyCommand";
	private static final String PASTE_COMMAND = "PasteCommand";
	private static final String CUT_COMMAND = "CutCommand";
	private static final String SHELL_COMMAND = "ShellCommand";
	private static final String DIFFICULTY_COMMAND = "DifficultyCommand";
	private static final String UNDO_COMMAND = "UndoCommand";
	private static final String REDO_COMMAND = "RedoCommand";
	private static final String RUN_COMMAND = "RunCommand";
	private static final String ASSIST_COMMAND = "AssistCommand";
	private static final String COMPILATION_COMMAND = "CompilationCommand";
	private static final String PREDICTION_COMMAND = "PredictionCommand";
	private static final String EXCEPTION_COMMAND = "ExceptionCommand";
	private static final String FIND_COMMAND = "FindCommand";

	private static final String FILE_PATH_ELEMENT = "filePath";
	private static final String SNAPSHOT_ELEMENT = "snapshot";
	private static final String DATA_ELEMENT = "data";
	
	public static void processCommand(CommandType command) {
		Byte repeat = command.getRepeat();
		if (repeat == null) {
			repeat = 1;
		}
//		if (!INSERT_STRING_COMMAND.equals(command.get_Type())) {
//			ProjectTracer.setInsert(false);
//		}
		
		if (MOVE_CARET_COMMAND.equals(command.get_Type())) {
			processMoveCaretCommand(command);
		} else if (FILE_OPEN_COMMAND.equals(command.get_Type())) {
			processFileOpenCommand(command);
		} else if (ECLISPE_COMMAND.equals(command.get_Type())) {
			processEclipseCommand(command);
		} else if (INSERT_STRING_COMMAND.equals(command.get_Type())) {
//			processInsertStringCommand(command, 1);
		} else if (COPY_COMMAND.equals(command.get_Type())) {
			processCopyCommand(command);
		} else if (PASTE_COMMAND.equals(command.get_Type())) {
			processPasteCommand(command, repeat);
		} else if (CUT_COMMAND.equals(command.get_Type())) {
//			processCutCommand(command);
		} else if (SELECT_TEXT_COMMAND.equals(command.get_Type())) {
			processSelectTextCommand(command);
		} else if (SHELL_COMMAND.equals(command.get_Type())) {
		} else if (DIFFICULTY_COMMAND.equals(command.get_Type())) {
		} else if (UNDO_COMMAND.equals(command.get_Type())) {
		} else if (RUN_COMMAND.equals(command.get_Type())) {
		} else if (ASSIST_COMMAND.equals(command.get_Type())) {
		} else if (COMPILATION_COMMAND.equals(command.get_Type())) {
		} else if (PREDICTION_COMMAND.equals(command.get_Type())) {
		} else if (EXCEPTION_COMMAND.equals(command.get_Type())) {
		} else if (FIND_COMMAND.equals(command.get_Type())) {
		} else {
			System.out.println("Unprocessed command type: " + command.get_Type());
		}
	}
	
	private static void processSelectTextCommand(CommandType command) {
		int start = command.getStart();
		int end = command.getEnd();
		int caret = command.getCaretOffset();
		System.out.println("\tSelecting string from " + start + " to " + end + " at " + caret);
		Document current = ProjectTracer.getCurrentFile();
		current.setSelect(start, end);
		current.setCursor(caret);
		if (caret == start) {
			ProjectTracer.markSelectingLeft();
		} else {
			ProjectTracer.markSelectingRight();
		}
		ProjectTracer.markSelected();
	}
	
	private static void processCopyCommand(CommandType command) {
		String copied = ProjectTracer.getCurrentFile().copySelection();
		System.out.println("\tCopying string of length " + copied.length() + " at " + ProjectTracer.getCaretPos());
		ProjectTracer.setCopied(copied);
	}
	
	private static void processPasteCommand(CommandType command, int repeat) {
		ProjectTracer.setInsert(false);
//		Serializable previous = ProjectTracer.getPrevious();
//		if (previous instanceof DocumentChangeType) {
//			System.out.println("\tPasting");
//			DocumentChangeProcessor.reprocessInsert((DocumentChangeType)previous);
//		}
//		String pasting = ProjectTracer.getCopied();
//		for (int i = 0; i < repeat; i ++) {
//			System.out.println("\tPasting string of length " + pasting.length() + " at " + ProjectTracer.getCaretPos());
//			ProjectTracer.getCurrentFile().insert(pasting);
//		}
	}
	
	private static void processCutCommand(CommandType command) {
		String copied = ProjectTracer.getCurrentFile().cutSelection();
		System.out.println("\tCutting string of length " + copied.length() + " at " + ProjectTracer.getCaretPos());
		ProjectTracer.setCopied(copied);
	}
	
	private static void processInsertStringCommand(CommandType command, int repeat) {
		ContentHelper contents = ContentHelper.mapContents(command.getContent());
		Optional<String> iData = contents.get(DATA_ELEMENT);
		if (iData.isPresent()) {
			String data = iData.get();
	
//			if (command.getLength() > data.length()) {
				data = data.replaceAll("\r?\n", "\r\n");
//			}
			if (ProjectTracer.wasInsert()) {
				String inserted = ProjectTracer.getInserted();
				inserted = inserted.replaceFirst("^\t+", "");
				String dataCopy = data.replaceFirst("^\t+", "");
				System.out.println("Ins:  " + Arrays.toString(inserted.getBytes()));
				System.out.println("Comp: " + Arrays.toString(dataCopy.getBytes()));
				if (inserted.startsWith(dataCopy)) {
					if (inserted.length() == dataCopy.length()) {
						ProjectTracer.setInsert(false);
					} else {
						ProjectTracer.setInserted(inserted.substring(dataCopy.length()));
					}
					return;
				} else {
					ProjectTracer.setInsert(false);
				}
			}
			for (int i = 0; i < repeat; i ++) {
				System.out.println("\tInserting string of length " + data.length() + " at " + ProjectTracer.getCurrentFile().getCursor());
				ProjectTracer.getCurrentFile().insert(data);
			}
	
			System.out.println("*** begin new file ***");
			System.out.println(ProjectTracer.getCurrentFile().getContents());
			System.out.println("*** end new file ***");
		} else {
			System.out.println("\tNo inserted string given");
		}
	}
	
	private static void processMoveCaretCommand(CommandType command) {
		System.out.println("\tMoving caret from " + ProjectTracer.getCaretPos() + " to " + command.getCaretOffset());
		ProjectTracer.setCaretPos(command.getCaretOffset());
	}
	
	private static void processEclipseCommand(CommandType command) {
		System.out.println("\tEclipse command: " + command.getCommandID());
		EclipseCommandProcessor.processEclipseCommand(command);
	}
	
	private static void processFileOpenCommand(CommandType command) {
		ContentHelper contents = ContentHelper.mapContents(command.getContent());
		Optional<String> fName = contents.get(FILE_PATH_ELEMENT);
		Optional<String> fContent = contents.get(SNAPSHOT_ELEMENT);
		if (!fName.isPresent()) {
			System.out.println("No file name found");
		} else {
			String name = fName.get().toLowerCase();
			System.out.println("\tOpening file: " + name);
			if (fContent.isPresent()) {
				String content = fContent.get();
				if (content.length() != command.getDocLength()) {
					content = content.replaceAll("\r?\n", "\r\n");
					fContent = Optional.of(content);
				}
			}
			if (ProjectTracer.hasFile(name)) {
				Document doc = ProjectTracer.getFile(name);
				if (fContent.isPresent()) {
					String content = fContent.get();
					if (!content.equals(doc.getContents())) {
						System.out.println("\t\tFile contents mismatch, updating with new. (Old len: " + doc.getLength() + ", New len: " + command.getDocLength() + ")");
						doc.setContents(content);
					}
				}
			} else {
				System.out.println("\t\tFile length: " + command.getDocLength());
				Document doc;
				if (!fContent.isPresent()) {
					doc = new EclipseDocument();
				} else {
					doc = new EclipseDocument(fContent.get());
				}
				ProjectTracer.addFile(name, doc);
			}
			ProjectTracer.setCurrentFileName(name);
			System.out.println("*** begin opened file ***");
			System.out.println(ProjectTracer.getCurrentFile().getContents());
			System.out.println("*** end opened file ***");
		}
	}
}
